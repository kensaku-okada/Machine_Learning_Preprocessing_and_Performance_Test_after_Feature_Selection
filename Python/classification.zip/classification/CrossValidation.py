#!/usr/bin/python3
#coding:utf-8

from sklearn import svm
from sklearn.model_selection import GridSearchCV, train_test_split

class CrossValidation:

	parameters = None

	def __init__(self, parameters):
		self.parameters = parameters



