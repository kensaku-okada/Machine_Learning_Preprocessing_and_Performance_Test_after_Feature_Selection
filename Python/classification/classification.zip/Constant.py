# -*- coding: utf-8 -*-
#!/usr/bin/python3

FILE_EXPORT_PATH = 'output\\'

# classifiers
SVC = "SVC"
NAIVE_BAYES = "naive_bayes"
C4_5 = "C4.5"

NON_BINARY_OUTPUT_DATASET = ["mushroom"]





