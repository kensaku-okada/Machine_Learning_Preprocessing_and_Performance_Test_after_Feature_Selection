#!/usr/bin/python3
#coding:utf-8

import os, sys, csv
import arff # for sparse arff dataset
import pandas as pd
import Constant

############### package for classification with cross validation ######################
from sklearn import svm
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.naive_bayes import GaussianNB
# from sklearn import tree
############### package for classification with cross validation ######################

def getFilePath(relativePath):

    # the directory where the main script is
    main_script_dir = os.getcwd()

    # move upto to the great parent path
    os.chdir("..\\..")
    print("os.path.abspath(os.curdir): ",os.path.abspath(os.curdir))

    filePath = os.path.abspath(os.curdir) + '\\' + relativePath
    # print("filePath: ",filePath)

    # get back to the the directory where the main script is
    os.chdir(main_script_dir)

    return filePath

# def readArffData(fileName, relativePath = "", skip_header=0, d=','):
def importArffData(filePath, dataSetType):
    '''
    source:
        https://discuss.analyticsvidhya.com/t/loading-arff-type-files-in-python/27419
        https://codeday.me/jp/qa/20190205/202735.html
    param relativePath: path to the file form the great parent folder
    return: dataset as pandas
    '''

    if dataSetType["outputDatasetType"] == "densed":
        # dataset = scipy_arff.loadarff(filePath)
        # # print("dataset[1]: ", dataset[1])
        # df = pd.DataFrame(dataset[0])

        data = arff.load(open(filePath))
        # print("data: ", data)
        # print("type(data): ", type(data))
        # print("len(data): ", len(data))

    elif dataSetType["outputDatasetType"] == "sparsed":
        # https://pypi.org/project/liac-arff/
        # https://laats.github.io/sw/mit/arff/
        # http://scikit.ml/datasets.html
        # (name, sparse, alist, m) = arff.arffread(open(filePath))

        # https://pythonhosted.org/liac-arff/
        data = arff.load(open(filePath), return_type=arff.LOD)

        # if you want to CV by sparse data, refer to the following:
        # https://stackoverflow.com/questions/33588658/stratified-kfold-on-sparsecsr-feature-matrixprint("data:", data)
        # https://medium.com/@yamasaKit/3-sparse%E3%81%AA%E3%83%87%E3%83%BC%E3%82%BF%E3%81%AB%E5%AF%BE%E3%81%99%E3%82%8Bscikit-learn%E3%81%AEsvm%E3%82%92svmlight-file%E3%81%A7%E9%AB%98%E9%80%9F%E5%8C%96%E3%81%99%E3%82%8B-4cc9e13529e9

    df = pd.DataFrame(data['data'])
    return df


# export dataset
def exportCSVFile(dataSet, header, fileName="exportFile"):

    currentDir = os.getcwd()
    print("currentDir: ", currentDir)

    #############################################
    # change the directory to export
    os.chdir(currentDir + "\\" + Constant.FILE_EXPORT_PATH)
    # print "os.getcwd():{}".format(os.getcwd())
    #############################################

    # #############################################
    # # depending on the change of design, you may want to save the outputs to the following path
    # os.chdir("\\\\192.168.1.60\\eGIS\\Development\\SecurityDoctor\\report\\output")
    # #############################################

    f = open(fileName + ".csv", 'w', encoding='utf-8')  # open the file with writing mode
    csvWriter = csv.writer(f, lineterminator="\n")
    # print('header',header)
    # print('dataSet[0]',dataSet[0])

    # is header is defined
    if header is not None:
        # write the header
        csvWriter.writerow(header)

    # write each row
    for data in dataSet:
        csvWriter.writerow(data)
    f.close()  # close the file

    # take back the current directory
    os.chdir(currentDir)
    # print "os.getcwd():{}".format(os.getcwd())

def get_clssifier_type_and_param_grid(classifier_name):

    if classifier_name == Constant.SVC:
        # syntax: https://scikit-learn.org/stable/auto_examples/model_selection/plot_grid_search_digits.html
        # parameters: https://www.csie.ntu.edu.tw/~cjlin/papers/guide/guide.pdf
        # C and γ is a practical method to identify good parameters (for example, C = 2^−5 , 2^−3 , . . . , 2^15 , γ = 2^−15 , 2^−13 , . . . , 2^3 ).
        C_params = [2 ** i for i in range(-5, 16, 2)]
        gamma_params = [2 ** i for i in range(-15, 4, 2)]
        print("C_params: ", C_params)
        print("gamma_params: ", gamma_params)
        parameters = {'kernel': ['rbf'], 'C': C_params, 'gamma': gamma_params}
        # https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
        # if gamma='scale' is passed then it uses 1 / (n_features * X.var()) as value of gamma.
        # svc = svm.SVC(gamma="scale")

        classifier_type = svm.SVC()

    elif classifier_name == Constant.NAIVE_BAYES:
        var_smoothing = [1e-09]
        parameters = {'var_smoothing': var_smoothing}

        # https://qiita.com/ynakayama/items/ca3f5e9d762bbd50ad1f
        # https://www.datacamp.com/community/tutorials/naive-bayes-scikit-learn
        classifier_type = GaussianNB()

    elif classifier_name == Constant.C4_5:
        classifier_type = None
        parameters = None
        # todo implement it referring to: https://scikit-learn.org/stable/modules/tree.html#tree-algorithms-id3-c4-5-c5-0-and-cart
        # https://www.quora.com/What-is-the-best-way-to-implement-C4-5-or-C5-0-algorithm-using-Python
    else:
        print("undefied classifier_name specified. stop the program")
        sys.exit(0)

    return classifier_type, parameters
