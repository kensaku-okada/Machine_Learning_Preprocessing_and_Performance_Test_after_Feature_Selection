#!/usr/bin/python3
#coding:utf-8

import os, sys, datetime, glob, pathlib
import numpy as np
# from scipy.io import arff as scipy_arff # for dense arff dataset
import pandas as pd
import Util, Constant, Test
# import matplotlib.pyplot as plt
############### package for preprocessing ######################
from sklearn.preprocessing import MultiLabelBinarizer, LabelEncoder, OneHotEncoder
############### package for preprocessing ######################
############### package for classification with cross validation ######################
from sklearn import svm
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.naive_bayes import GaussianNB
# from sklearn import tree
############### package for classification with cross validation ######################

# "outputDatasetType" = "densed" or "sparsed"
datasetType = {"importDatasetFormat": "arff", "outputDatasetType": "densed"}

########### specify the dataset start ##############
# if you want to process multiple files, active below
# ifGetMultipleResults = True
# relativePath = "datasets\\dorothea\\*bornfs.arff"

# if you want to process only one file, active below
ifGetMultipleResults = False
# relativePath = "datasets\\mushroom\\mRMR\\mushroom_mrmr.arff"
relativePath = "datasets\\arcene\\mRMR\\arcene-10-disc_mrmr.arff"
# relativePath = "datasets\\dorothea\\dorothea.sparse.arff.0.5.bornfs.arff"
########### specify the dataset end ##############

filePath = Util.getFilePath(relativePath)
print("filePath: ",filePath)
# https://note.nkmk.me/python-pathlib-name-suffix-parent/
dataset_directory = pathlib.Path(filePath)
print("dataset_directory: ",dataset_directory)
dataset_name = pathlib.Path(filePath).parents[1].name
print("dataset_name: ",dataset_name)

if ifGetMultipleResults:
    # print("glob.glob(filePath): ",glob.glob(filePath))
    file_paths = glob.glob(filePath)
else:
    # adjust the file format with the case ifGetMultipleResults = True
    file_paths = [filePath]

# compared classifiers
# classifier_names = [Constant.SVC, Constant.NAIVE_BAYES, Constant.C4_5]
classifier_names = [Constant.SVC, Constant.NAIVE_BAYES]
# classifier_names = [Constant.NAIVE_BAYES]
# classifier_names = [Constant.SVC]

test_results = []

for filePath in file_paths:

    print("filePath: ",filePath)

    # import data
    dataset = Util.importArffData(filePath, datasetType)
    print("type(dataset): ",type(dataset))
    print("dataset.shape: ",dataset.shape)
    print("dataset.head(5):{}".format(dataset.head(5)))

    ####################################################################
    ############### preprocessing start ###############
    ####################################################################

    # when processing mushroom_mrmr.arff, you want to use below
    if dataset_name == "mushroom":
        # https://towardsdatascience.com/building-a-perfect-mushroom-classifier-ceb9d99ae87e

        # binarize the dataset
        # https://note.nkmk.me/python-pandas-get-dummies/
        dataset_binary = pd.get_dummies(dataset)
        print("type(dataset_binary): ", type(dataset_binary))
        print("dataset_binary.shape: ", dataset_binary.shape)
        print("dataset_binary.head(5):{}".format(dataset_binary.head(5)))

        X_binary = dataset_binary.iloc[:, 0:len(dataset_binary.columns) - 1].values
        y_binary = dataset_binary.iloc[:, len(dataset_binary.columns) - 1].values
        print("type(X_binary): ", type(X_binary))
        print("X_binary.shape: ", X_binary.shape)
        print("type(y_binary): ", type(y_binary))
        print("y_binary.shape: ", y_binary.shape)
        # print("y: ", y)
        # print("y[0][0]: ", y[0])
        # print("type(y[0][0]): ", type(y[0]))

        ###################### old code for character binarization ######################
        # import itertools
        # # TypeError: unorderable types: NoneType() < str()
        # X_binary = np.empty((X.shape[0], X.shape[1]))
        # # source: https://www.datatechnotes.com/2019/05/one-hot-encoding-example-in-python.html
        # for i in range (0, X.shape[0]):
        #     x_numerical = LabelEncoder().fit_transform(X[i])
        #     print("x_numerical: ",x_numerical)
        #     onehot_encoder = OneHotEncoder(sparse=False)
        #     x_numerical_reshaped = x_numerical.reshape(len(x_numerical), 1)
        #     x_binary = onehot_encoder.fit_transform(x_numerical_reshaped)
        #     print("x_binary: ",x_binary)
        #     # change the 2 dim array into 1 array by concatenating the elements
        #     # https://note.nkmk.me/python-list-flatten/
        #     x_binary = list(itertools.chain.from_iterable(x_binary))
        #     X_binary[i] = x_binary
        ###################### old code for character binarization ######################

        # divide data into training data and test data by 1:4 = test : train
        # if you want change the random pattern each time, remove random_state=0
        # random_state=: データを分割する際の乱数のシード値 (https://docs.pyq.jp/python/machine_learning/tips/train_test_split.html)
        # https://qiita.com/tomov3/items/039d4271ed30490edf7b
        # X_train, X_test, y_train, y_test = train_test_split(X_binary, y, test_size=0.2, random_state=0)
        X_train, X_test, y_train, y_test = train_test_split(X_binary, y_binary, test_size=0.2, random_state=0)

    else:
        X = dataset.iloc[:, 0:len(dataset.columns) - 1].values
        y = dataset.iloc[:, len(dataset.columns) - 1].values
        print("type(X): ", type(X))
        print("X.shape: ", X.shape)
        print("type(y): ", type(y))
        print("y.shape: ", y.shape)
        # print("y: ", y)
        # print("y[0][0]: ", y[0])
        # print("type(y[0][0]): ", type(y[0]))

        # just change the data type of y from string to int
        y = y.astype(np.int32)

        # binarize the data to resolve the following error
        # ValueError: You appear to be using a legacy multi-label data representation. Sequence of sequences are no longer supported; use a binary array or sparse matrix instead.
        # source: https://stackoverflow.com/questions/34213199/scikit-learn-multilabel-classification-valueerror-you-appear-to-be-using-a-leg
        # https://github.com/phanein/deepwalk/issues/32
        X_binary = MultiLabelBinarizer().fit_transform(X)

        # divide data into training data and test data by 1:4 = test : train
        # if you want change the random pattern each time, remove random_state=0
        # random_state=: データを分割する際の乱数のシード値 (https://docs.pyq.jp/python/machine_learning/tips/train_test_split.html)
        # https://qiita.com/tomov3/items/039d4271ed30490edf7b
        # X_train, X_test, y_train, y_test = train_test_split(X_binary, y, test_size=0.2, random_state=0)
        X_train, X_test, y_train, y_test = train_test_split(X_binary, y, test_size=0.2, random_state=0)

    print("X_binary: ", X_binary)
    print("X_binary.shape: ", X_binary.shape)
    # print("y.shape: ", y.shape)
    # print("y]: ", y)
    # print("y[0]: ", y[0])
    # print("type(y[0]): ", type(y[0]))
    print("X_train.shape: ", X_train.shape)
    # print("X_train: ", X_train)
    print("X_test.shape: ", X_test.shape)
    print("y_train.shape: ", y_train.shape)
    # print("y_train: ", y_train)
    print("y_test.shape: ", y_test.shape)

    # convert from Byte code to String, and from String to int, which is necessayr only when the date is byte type.
    # https://qiita.com/masakielastic/items/2a04aee632c62536f82c
    if type(y_train) is bytes:
        y_train = np.array([int(y_e.decode('utf-8')) for y_e in y_train])
        # print("y_train: ", y_train)
        # print("y_train.shape: ", y_train.shape)
        # print("type(y_train): ", type(y_train))
        # print("y_train[0]: ", y_train[0])
        # print("type(y_train[0]): ", type(y_train[0]))
    ####################################################################
    ############### preprocessing end ###############
    ####################################################################

    for classifier_name in classifier_names:
        ####################################################################
        ############### classification with cross validation start ######################
        ####################################################################
        clssifier_type, parameters = Util.get_clssifier_type_and_param_grid(classifier_name)

        # GridSearchCV
        # https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GridSearchCV.html
        # https://qiita.com/yhyhyhjp/items/c81f7cea72a44a7bfd3a
        # http://starpentagon.net/analytics/scikit_learn_grid_search_cv/
        clf = GridSearchCV(estimator=clssifier_type, param_grid=parameters, cv=10)

        print ("start clf.fit at :{}".format(datetime.datetime.now()))
        clf.fit(X_train, y_train)
        print ("end clf.fit at :{}".format(datetime.datetime.now()))

        # print("clf.cv_results_: ",clf.cv_results_)
        print("clf.best_params: ",clf.best_params_ )
        print("clf.best_score_: ",clf.best_score_ )
        print("clf.best_estimator_: ",clf.best_estimator_)
        print("clf.best_index_: ",clf.best_index_)
        ###########################################################################
        ############### classification with cross validation end ######################
        ###########################################################################

        ###########################################################################
        ############### test the model start ####################
        ###########################################################################
        print("------------ start testing the model ------------")
        classifier, accuracy, f_measure, my_roc_auc_score = Test.test_model(classifier_name, clf, X_test, y_test)

        # append the test result for export
        file_name = os.path.basename(filePath)
        test_results.append([file_name ,classifier ,accuracy ,f_measure ,my_roc_auc_score])
        print("------------ end testing the model ------------")
        ###########################################################################
        ############### test the model end ######################
        ###########################################################################

############### export the test result ###############
header = ["file_name","classifier","accuracy","f-measure","ROC-AUC"]
# https://note.nkmk.me/python-pathlib-name-suffix-parent/
Util.exportCSVFile(test_results, header, fileName=dataset_directory.parents[1].name + "_test_result")


################################################################
# Reference (not used)
# https://stackoverflow.com/questions/22165641/install-libsvm-for-python-in-windows
# http://tkoyama1988.hatenablog.com/entry/2013/12/09/125143
# author of this library https://www.csie.ntu.edu.tw/~cjlin/libsvm/#download

# sys.path.append('C:\\Users\\kensa\\Downloads\\libsvm-3.12\\python\\')
# from svm import *
# from svmutil import *
#
# data1 = [[1,-2,3],[1,-4,5,1234],[342,342,435345,43534,4352,-4]] #データ
# label1 = [-1,-1,-1] #データの正負（±１のラベル）
# prob = svm_problem(label1 , data1) # データとラベルを合成
# param = svm_parameter('-s 0 -t 0') # 学習方法の設定
# m = svm_train(prob, param) #学習
# result = svm_predict([-1,-1],[[34,453.5],[45356,-10]] , m) #未知データの適用
################################################################

################################################################
# Reference (not used)
# cross_validation package
# https://qiita.com/yhyhyhjp/items/d4b796f7658b7e5be3b6
################################################################
